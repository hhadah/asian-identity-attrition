# asian-identity-attrition
This is a repo for my project on racial attrition among Asian Americans.
